#include "LDR.h"

void LDR_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd (LDR_GPIO_CLK, ENABLE );	// �� ADC IO�˿�ʱ��
	GPIO_InitStructure.GPIO_Pin = LDR_GPIO_PIN;					// ���� ADC IO ����ģʽ
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;		// ����Ϊģ������
	
	GPIO_Init(LDR_GPIO_PORT, &GPIO_InitStructure);				// ��ʼ�� ADC IO

	ADCx_Init();
	
}
	
uint16_t LDR_ADC_Read(void)
{
	//����ָ��ADC�Ĺ�����ͨ��������ʱ��
	return ADC_GetValue(ADC_CHANNEL, ADC_SampleTime_55Cycles5);
}
	
uint16_t LDR_Average_Data(void)
{
	uint32_t  tempData = 0;
	for (uint8_t i = 0; i < LDR_READ_TIMES; i++)
	{
		tempData += LDR_ADC_Read();
		Delay_ms(5);
	}

	tempData /= LDR_READ_TIMES;
	return (uint16_t)tempData;
}

uint16_t LDR_LuxData()
{
	float voltage = 0;	
	float R = 0;	
	uint16_t Lux = 0;
	voltage = LDR_Average_Data();
	voltage  = voltage / 4096 * 3.3f;
	
	R = voltage / (3.3f - voltage) * 10000;
		
	Lux = 40000 * pow(R, -0.6021);
	
	if (Lux > 999)
	{
		Lux = 999;
	}
	return Lux;
}

//void LDR_LuxData(uint16_t *Lux)
//{
//	float voltage = 0;	
//	float R = 0;	
//	voltage = LDR_Average_Data();
//	voltage  = voltage / 4096 * 3.3f;
//	
//	R = voltage / (3.3f - voltage) * 10000;
//		
//	*Lux = 40000 * pow(R, -0.6021);
//	
//	if (*Lux > 999)
//	{
//		*Lux = 999;
//	}
//}

