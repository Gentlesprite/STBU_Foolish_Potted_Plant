#include "led.h"

uint16_t LED_Hint_Counter =0;//LED��ʾ��0-600s
void LED_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOE, GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5);
//	GPIO_ResetBits(GPIOF, GPIO_Pin_2);
}




void LED2_ON(void)
{
	GPIO_ResetBits(GPIOE, GPIO_Pin_5);
}

void LED2_OFF(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_5);
}

void LED2_Turn(void)
{
	if (GPIO_ReadOutputDataBit(GPIOE, GPIO_Pin_5) == 0)
	{
		GPIO_SetBits(GPIOE, GPIO_Pin_5);
	}
	else
	{
		GPIO_ResetBits(GPIOE, GPIO_Pin_5);
	}
}

void RELAY_OFF(void)//�̵���ˮ�� PE 2
{
	GPIO_ResetBits(GPIOE, GPIO_Pin_2);
}

void RELAY_ON(void)
{
	
	GPIO_SetBits(GPIOE, GPIO_Pin_2);
}

void BUZZER_OFF(void) //������ PE 3
{
	GPIO_ResetBits(GPIOE, GPIO_Pin_3);
}

void BUZZER_ON(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_3);
}

void FAN_ON(void)  //���� PE 4 3.3V�͵�ƽ����
{
	GPIO_ResetBits(GPIOE, GPIO_Pin_4);
}

void FAN_OFF(void)
{
	GPIO_SetBits(GPIOE, GPIO_Pin_4);
}

void LED_Hint(uint16_t timer)//LED��ʾ��
{
	LED2_OFF();
	LED2_ON();
	LED_Hint_Counter =timer;
	
}
void LEDM_ON(){
	GPIO_SetBits(GPIOB,GPIO_Pin_1);
}
void LEDM_OFF(){
GPIO_ResetBits(GPIOB,GPIO_Pin_1);
}
